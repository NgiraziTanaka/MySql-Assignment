<?php
	include_once('connect.php');
	$queryString='
	CREATE TABLE Airline_Passengers
	(
		Title varchar(5),
		Surname varchar(10),
		FirstName varchar(10),
        Contact varchar(10),
        Email varchar(10),
        Gender varchar(10),
        Password varchar(10) PRIMARY KEY,
        LeavingFrom varchar(10),
        GoingTo varchar(10),
        DateOfDepature varchar(10),
        DateOfReturn varchar(10),
        NumberOfAdultsTravelling varchar(10),
        NumberOfChildrenTravelling varchar(10),
        NumberOfInfantsTravelling varchar(10),
        ConditionsOfTravelAfrica varchar(10)

	);
';

	if($airline_conn->query($queryString)){
		echo "Table created successfully";
	}
	else{
		echo "not created";
	}
		


?>