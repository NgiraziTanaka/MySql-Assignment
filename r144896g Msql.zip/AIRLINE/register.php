

<!DOCTYPE html>
<html>
<title>
     TravelAfrica 
</title>
<link rel="stylesheet" href="css/Bootstrap.css" />
<script type"text/javascript" src="jquery-1.12.3.min"></script>
<script type="text/javascript" src="js/index.js"></script>
<script type="text/javascript" scr="jquiryValidation.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.15.0/jquery.validate.min.js">
</head>
<body >
	
	
<div id="container">
	
	
	<header role="banner" id="main-header">
		<div id="logo">
		</div>
		
		<nav id="main_nav">
		<br><br>
		<address>
  <strong>TravelAfrica.</strong><br>
  14 Diamond Street<br>
  HARARE, HRE 94107<br>
  <abbr title="Phone">P:</abbr> +263 774 517 086
  
  <br>
</address>

			<ul>

				<li><a href="travelAfrica.html">Home</a></li>
				<li><a href="travelAfrica.html">About </a></li>
               <li><a href="travelAfrica.html">Contant </a></li>
               <li><a href="travelAfrica.html"> Help</a>

				
			</ul>
		</nav>
              
<center>
  <h1> <u>TRAVEL AFRICA</u> <br><i><h6>*travell with the stars*</h6></i> </h1>
  <img src="travelafrica.jpeg">


</center>
              




      <hr>
	</header>
	<section id="content">	      	
	</section>
	
</div>

<p>	
       <nav id="left_nav">
              <div class="container">

     <form class="form-inline" role="form"  action="Handler.php" method="POST"> 

                        <fieldset>

                                   <p class="bg-primary">**basic information</p>
                      <br>
					  <div class="form-group">
				
			</div>
								<div class="form-group">
                                <label for="First Name">Title</label>
                                <input type="text"  id="titleId" name="title" required="required">
                              </div>
                               <br>
                              <div class="form-group" >
                                <label for="Surname">Surname</label>
                                <input type="text"  id="SurnameId" name="surname" required="required">
                              </div>
                             <br>

                               <div class="form-group">
                                <label for="First Name">First Name</label>
                                <input type="text"  id="First NameId" name="name" required="required">
                              </div>
                               <br>

                               <div class="form-group">
                                <label for="Contact ">Contact Number</label>
                                <input type="text"  id="ContactId" placeholder="0774 517 086" name="contact" required="required"  maximum="10">
                              </div>
                                
                                <div class="form-group">
                                <label for="e-mail ">Email address</label>
                                <input type="text" class="form-control" id="emailId" name="email" required="required" placeholder="ngirazitanaka@gmail.com">
                              </div>

                              <div class="form-group">
                                <label for="password">Password</label>
                                <input type="text"  id="passwordId" required="required" name="password" placeholder="rXXXXXXXX">
                              </div>
							
							<div class="form-group">
                                <label for="password">Gender</label>
                                <input type="text"  id="genderId" required="required" name="gender" placeholder="male or female?">
                              </div>


                                 
                                
      <hr>

</fieldset>


                       
                                     <p class="bg-primary">**COUNTRY</p>




                                       <p><h3>Select country</h3></p>
                                      <select>
                                          <option value="country">Zimbabwe</option>
                                          <option value="country">South Africa</option>
                                      </select><br>

                                      <br>
                               <div class="form-group">
                                <label for="Leaving From ">Leaving From </label>
                                <input type="Leaving From " name="country" id="Leaving FromId">
                              </div>
                            

                               <div class="form-group">
                                <label for="Going To">Going To </label>
                                <input type="Going To " required="required" name="country1" id="Going ToId">
                              </div>
                               
                               <label for="dod">Date Of Depature</label>
                               <input type="date" name="dod" required="required" ></input>
                               <br><br>

                                <label for="dob">Date Of Return</label>
                                <input type="date" name="dor" required ></input> 

                                   <br><br>




                                   <p class="bg-primary">**Name your Flight</p>
								   <br>
                                   <select>

                                          <option value="FastDiamond">FastDiamond</option>
                                          <option value="14Diamonds">14Diamonds</option>
                                          <option value="TN14">TN14</option>

                                    </select>
									<br>
                                 <s>****TRAVELING TIMES WILL BE PROVIDED IN DUE COURSE ****</s>

      <hr>
                                   <p class="bg-primary">**PassengerS</p>
                            <div class="form-group">
                                          <label for="ADULTS">Number of adults Travelling</label>
                                          <input type="number" name="adultsN" required="required" id="adultsId">
                            </div>
                            <br>

                            <div class="form-group">
                                          <label for="CHILDREN">Number of children under 12 years Travelling</label>
                                          <input type="number" required="required" name="childrenN" id="childrenId">
                            </div>
                            <br>

                             <div class="form-group">
                                          <label for="Infants">Number of infants under 2 years Travelling</label>
                                          <input type="number" name="infantsN" required="required" id="childrenId">
                            </div>
                            <br>





                            <p><h3>Type of Ticket</h3></p>
                            <select>
       
                                          <option value="Silver">Silver</option>
                                          <option value="Gold">Gold</option>
                                          <option value="Platinum">Platinum</option>

                                    </select>

                            <br></br>

                             <div class="checkbox">
                                          <label>
                                          <input type="text" name="agree" required="required">
                                          I agree to the terms and conditions of TravelAfrica..
                                          </label>
                            </div>
                             <button type="submit" class="btn btn-primary">Submit</button>
                            </fieldset>




                     </form>

              </div>
       </nav> 
<br><br>

<button type="button" class="btn btn-info">like TravelAfrica on facebook</button>
<button type="button" class="btn btn-warning">follow TravelAfrica on twitter</button>
<button type="button" class="btn btn-danger">Exit Trave Africa Page</button>
</body>







</html>

