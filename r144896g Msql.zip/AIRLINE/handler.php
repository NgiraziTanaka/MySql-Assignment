
<?php
 include_once('connect.php');
 $Title =$_POST["title"];
 $Surname =$_POST["surname"];
 $FirstName =$_POST["name"];
 $Contact =$_POST["contact"];
 $Email =$_POST["email"];
 $Gender =$_POST["gender"];
 $Password=$_POST["password"];
 $LeavingFrom=$_POST["country"];
 $GoingTo=$_POST["country1"];
 $DateOfDepature=$_POST["dod"];
 $DateOfReturn=$_POST["dor"];
 $NumberOfAdultsTravelling=$_POST["adultsN"];
 $NumberOfChildrenTravelling=$_POST["childrenN"];
 $NumberOfInfantsTravelling=$_POST["infantsN"];
 $ConditionsOfTravelAfrica=$_POST["agree"];


echo "$email, $Name";

	
	$queryString="
 INSERT INTO Policy_Holders
 Values ('$title ,$surname,$FirstName ,$Contact,$Email ,$Gender,$Password,$LeavingFrom,$GoingTo,$DateOfDepature,$DateOfReturn,$NumberOfAdultsTravelling,$NumberOfChildrenTravelling,$NumberOfInfantsTravelling,$ConditionsOfTravelAfrica')
   ";

  if($airline_conn->query($queryString)){
	   
   echo "Data inserted successfully";
   }
//$_SESSION['welcome'] = $index;
 //header("Location: logged_on.php")
	  ?>
	