<?php

$airline_conn=new mysqli('localhost','airline1user','1234','airline1_db');
  if($airline_conn->connect_errno){
	  
	  echo "Error".$airline_conn->connect_errno." has occured";
	  
  }else{
		
	
  }
	
?>

